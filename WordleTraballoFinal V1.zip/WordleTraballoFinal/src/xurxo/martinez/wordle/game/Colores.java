/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package xurxo.martinez.wordle.game;

/**
 *
 * @author xurxo
 */
public enum Colores {
    VERDE, ROJO, AMARILLO;
}
